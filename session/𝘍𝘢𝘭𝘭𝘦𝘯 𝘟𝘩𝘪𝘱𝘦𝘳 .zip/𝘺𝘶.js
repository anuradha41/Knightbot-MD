𝙟𝙖𝙣 𝙡𝙪𝙥𝙖 𝙛𝙤𝙡𝙡𝙤𝙬 𝙘𝙝𝙖𝙣𝙣𝙚𝙡 𝙙𝙚𝙫 𝙮𝙖𝙝 𝙗𝙖𝙗𝙞. 

𝙘𝙝𝙖𝙣𝙣𝙚𝙡 𝙬𝙖:
https://whatsapp.com/channel/0029VaoF3P2Elah1jmqLIn1j

𝙘𝙝𝙖𝙣𝙣𝙚𝙡 𝙩𝙚𝙡𝙚:
https://t.me/+jiZRxvBNJQk2ZDdl

𝙘𝙧𝙚𝙙𝙞𝙩𝙨:
𝙡𝙪𝙗𝙯𝙮𝙭 (𝙠𝙖𝙣𝙜 𝙗𝙚𝙠𝙙𝙤𝙧) 
𝘠𝘶𝘬𝘪𝘯𝘢-𝘏𝘪𝘪𝘳𝘢𝘨𝘪 (𝙘𝙧𝙚𝙖𝙩𝙤𝙧) 

𝙋𝙬 𝘿𝙞 𝙕𝙞𝙥:
Lucifer-nih-boss